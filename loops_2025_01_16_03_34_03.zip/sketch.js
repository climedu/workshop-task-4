function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(100);
  
  noFill();
  stroke(250,120,10);
  
  for(let i=0; i<60; i++) {
    strokeWeight (i*0.2)
    ellipse(200,200,100+20*i)
  }
}